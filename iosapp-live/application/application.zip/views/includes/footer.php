<footer id="footer" class="cf">
        <div class="credits"><a href="http://blankandco.com" target="BuiltByBlank" title="Built by Blank & Co.">Built by <span>Blank & Co.</span></a>
        </div>
    </footer>
</body>

</html>