<?php $this->load->view('includes/header.php'); ?>
<?php $this->load->view($main_content); ?>
<?php $this->load->view('includes/footer.php'); ?>