<?php 


$config['protocol']     = 'smtp';
$config['smtp_host']    = 'ssl://smtp.googlemail.com';
$config['smtp_port']    = '465';
$config['smtp_timeout'] = '7';
$config['smtp_user']    = 'kishoreamit5@gmail.com';
$config['smtp_pass']    = 'pr@t@type@1993#';
$config['charset']      = 'utf-8';
$config['newline']      = "\r\n";
$config['mailtype']     = 'text'; // or html
$config['validation']   = TRUE; // bool whether to validate email or not 
