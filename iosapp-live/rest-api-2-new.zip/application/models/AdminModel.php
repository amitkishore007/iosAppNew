<?php 

/**
* 
*/
class AdminModel extends CI_Model
{
	

	
	public function check_login($info) {

		$this->load->library('form_validation');

		if ($this->form_validation->run('login_form_validation')==TRUE) {
		
			$info['password'] = md5($info['password']);
			$result = $this->db->where($info)->get('admin');
			$admin  = $result->row();

			// print_r($admin->id);

			if (count($admin)) {
					
				
				return $admin;

			} else {

			 return false;
 
			}

		} else {

			return false;
		}

	}

	public function find_admin_by_id($id) {

		return $this->db->where(['id'=>$id])->get('admin')->result();
	}


	public function add_user($info) {

	}

	public function update_user() {

	}

	public function delete_user() {

	}


}