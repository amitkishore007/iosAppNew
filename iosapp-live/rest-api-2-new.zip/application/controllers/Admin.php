<?php 
// admin controller 

defined('BASEPATH') OR exit('No direct script access allowed');


/**
* 
*/
class Admin extends CI_Controller
{
	

	public function __construct() {

		parent::__construct();
		$this->load->model('adminModel');
	}

	public function index() {

		$data['main_content'] = 'admin/login';
		$this->load->view('includes/template',$data);

	}
	private function set_message($status, $msg) {
	
		return  ['status'=>$status,'message'=>$msg];
	
	}

	public function login() {
		

		if ($this->input->post('submit')) {
			
			$output = array('status'=>false,'message'=>'');

			unset($_POST['submit']);
			
			$admin = $this->adminModel->check_login($this->input->post());
			  
			
			if ($admin) {
			

				$info = array(
					'admin_id'=>$admin->id,
					'admin_email'=>$admin->email,
					'is_logged_in'=>true
					);
				$this->session->set_userdata($info);
				$output['status'] = true;
				$outout['message'] = 'success';
		      	

			} else {

				$output['status']  = false;
				$outout['message'] = 'Email/password did not matched';
		    
				
			}

			echo json_encode($output);

		} else {

			 return json_encode($this->set_message(TRUE,'no direct access'));
		}


	}

	public function register() {

	}

	public function edit_user() {

	}

	public function delete_user() {

	}

	public function store_data() {

	}


}
